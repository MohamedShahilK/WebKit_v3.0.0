package com.example.webkit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
