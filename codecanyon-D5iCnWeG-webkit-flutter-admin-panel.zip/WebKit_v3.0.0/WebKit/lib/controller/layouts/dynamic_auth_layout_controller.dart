import 'package:flutter/material.dart';
import 'package:webkit/controller/my_controller.dart';

class DynamicAuthLayoutController extends MyController {
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey();
  final scrollKey = GlobalKey();
}
