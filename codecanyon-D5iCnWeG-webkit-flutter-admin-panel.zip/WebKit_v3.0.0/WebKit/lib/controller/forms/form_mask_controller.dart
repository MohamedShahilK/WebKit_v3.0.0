import 'package:webkit/controller/my_controller.dart';

class FormMaskController extends MyController {}
