import 'package:webkit/controller/my_controller.dart';

class Error500Controller extends MyController {}
