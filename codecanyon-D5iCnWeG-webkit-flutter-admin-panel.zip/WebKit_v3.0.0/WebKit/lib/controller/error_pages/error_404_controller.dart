import 'package:webkit/controller/my_controller.dart';

class Error404Controller extends MyController {}
