import 'package:webkit/controller/my_controller.dart';

class MaintenanceController extends MyController {}
