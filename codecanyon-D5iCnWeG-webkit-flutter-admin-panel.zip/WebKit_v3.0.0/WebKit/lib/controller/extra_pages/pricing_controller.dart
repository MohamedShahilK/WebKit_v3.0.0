import 'package:webkit/controller/my_controller.dart';

class PricingController extends MyController {
  int currentTabId = 1;
}
