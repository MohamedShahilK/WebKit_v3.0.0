abstract class MyMiddleware {
  String name = 'middleware';

  String handle(String routeName);
}
